﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using questionnaire.questionnaire.Authentication;
using questionnaire.questionnaire.DTOs;
using Web.Models;

namespace questionnaire.questionnaire.Controllers
{
    [Route("auth")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly QuestionnaireContext _context;
        private readonly TokenService _tokenService;
        private readonly ILogger<AccountController> _logger;

        public AccountController(QuestionnaireContext context, TokenService tokenService, ILogger<AccountController> logger)
        {
            _context = context;
            _tokenService = tokenService;
            _logger = logger;
        }

        [AllowAnonymous]
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] questionnaire.DTOs.RegisterRequest request)
        {
            try
            {
                // Проверка уникальности email и username
                if (await _context.Users.AnyAsync(u => u.Email == request.Email))
                {
                    return BadRequest(new { Message = "Email уже занят." });
                }

                if (await _context.Users.AnyAsync(u => u.Username == request.Username))
                {
                    return BadRequest(new { Message = "Имя пользователя уже занято." });
                }

                // Проверка прав текущего пользователя
                var currentUserId = GetCurrentUserId();
                if (currentUserId.HasValue)
                {
                    var currentUser = await _context.Users.FindAsync(currentUserId.Value);
                    if (currentUser != null && request.AccessLevelId == AuthOptions.AdminRoleId &&
                        currentUser.AccessLevelId != AuthOptions.AdminRoleId)
                    {
                        return Forbid("Только администраторы могут создавать других администраторов");
                    }
                }
                else if (request.AccessLevelId == AuthOptions.AdminRoleId)
                {
                    request.AccessLevelId = AuthOptions.RespondentRoleId;
                }

                // Хэширование пароля
                var hasher = new PasswordHasher<User>();
                var user = new User
                {
                    Username = request.Username,
                    Email = request.Email,
                    PasswordHash = hasher.HashPassword(null, request.Password),
                    AccessLevelId = request.AccessLevelId,
                    PhotoUrl = null
                };

                // Сохранение пользователя
                await _context.Users.AddAsync(user);
                await _context.SaveChangesAsync();

                // Генерация токенов
                var accessToken = _tokenService.GenerateAccessToken(user);
                var refreshToken = _tokenService.GenerateRefreshToken();

                // Сохранение refresh token
                var userToken = new Token
                {
                    UserId = user.Id,
                    RefreshToken = refreshToken,
                    RefreshTokenDatetime = DateTime.UtcNow.AddDays(7)
                };

                await _context.Tokens.AddAsync(userToken);
                await _context.SaveChangesAsync();

                _logger.LogInformation($"Пользователь {user.Username} успешно зарегистрирован с ролью {AuthOptions.GetRoleName(user.AccessLevelId)}");

                return Ok(new
                {
                    access_token = accessToken,
                    refresh_token = refreshToken,
                    user = new
                    {
                        user.Id,
                        user.Username,
                        user.Email,
                        Role = AuthOptions.GetRoleName(user.AccessLevelId),
                        RoleId = user.AccessLevelId
                    }
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при регистрации пользователя");
                return StatusCode(500, new { Message = "Не удалось зарегистрировать пользователя." });
            }
        }

        [AllowAnonymous]
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] questionnaire.DTOs.LoginRequest request)
        {
            try
            {
                var user = await _context.Users
                    .Include(u => u.AccessLevel)
                    .SingleOrDefaultAsync(u => u.Username == request.Login || u.Email == request.Login);

                if (user == null)
                {
                    return BadRequest(new { Message = "Неверный логин/email или пароль." });
                }

                var hasher = new PasswordHasher<User>();
                var verificationResult = hasher.VerifyHashedPassword(user, user.PasswordHash, request.Password);

                if (verificationResult == PasswordVerificationResult.Failed)
                {
                    return BadRequest(new { Message = "Неверный пароль." });
                }

                // Генерация токенов
                var accessToken = _tokenService.GenerateAccessToken(user);
                var refreshToken = _tokenService.GenerateRefreshToken();

                // Удаление старых refresh токенов
                var existingTokens = await _context.Tokens.Where(t => t.UserId == user.Id).ToListAsync();
                if (existingTokens.Any())
                {
                    _context.Tokens.RemoveRange(existingTokens);
                }

                // Сохранение нового refresh токена
                var userToken = new Token
                {
                    UserId = user.Id,
                    RefreshToken = refreshToken,
                    RefreshTokenDatetime = DateTime.UtcNow.AddDays(7)
                };

                await _context.Tokens.AddAsync(userToken);
                await _context.SaveChangesAsync();

                _logger.LogInformation($"Пользователь {user.Username} успешно вошел в систему");

                return Ok(new
                {
                    access_token = accessToken,
                    refresh_token = refreshToken,
                    user = new
                    {
                        user.Id,
                        user.Username,
                        user.Email,
                        user.PhotoUrl,
                        Role = AuthOptions.GetRoleName(user.AccessLevelId),
                        RoleId = user.AccessLevelId,
                        CanCreate = AuthOptions.CanCreateQuestionnaires(user.AccessLevelId),
                        IsAdmin = AuthOptions.IsAdmin(user.AccessLevelId)
                    }
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при входе пользователя");
                return StatusCode(500, new { Message = "Ошибка при входе в систему." });
            }
        }

        [Authorize]
        [HttpPost("logout")]
        public async Task<IActionResult> Logout()
        {
            try
            {
                var userId = GetCurrentUserId();
                if (!userId.HasValue)
                {
                    return Unauthorized(new { Message = "Неверный пользователь." });
                }

                var userTokens = await _context.Tokens.Where(t => t.UserId == userId.Value).ToListAsync();
                if (userTokens.Any())
                {
                    _context.Tokens.RemoveRange(userTokens);
                    await _context.SaveChangesAsync();
                }

                _logger.LogInformation($"Пользователь {userId} вышел из системы");
                return Ok(new { Message = "Пользователь успешно вышел." });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при выходе пользователя");
                return StatusCode(500, new { Message = "Ошибка при выходе из системы." });
            }
        }

        [AllowAnonymous]
        [HttpPost("refresh")]
        public async Task<IActionResult> Refresh([FromBody] RefreshTokenRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.RefreshToken))
                {
                    return BadRequest(new { Message = "Refresh token обязателен." });
                }

                var principal = _tokenService.GetPrincipalFromToken(request.AccessToken);
                if (principal == null)
                {
                    return BadRequest(new { Message = "Неверный access token." });
                }

                var userIdClaim = principal.FindFirst(AuthOptions.UserIdClaimType)?.Value;
                if (!int.TryParse(userIdClaim, out int userId))
                {
                    return BadRequest(new { Message = "Неверный access token." });
                }

                var storedToken = await _context.Tokens
                    .FirstOrDefaultAsync(t => t.UserId == userId && t.RefreshToken == request.RefreshToken);

                if (storedToken == null || storedToken.RefreshTokenDatetime < DateTime.UtcNow)
                {
                    return BadRequest(new { Message = "Неверный или просроченный refresh token." });
                }

                var user = await _context.Users.FindAsync(userId);
                if (user == null)
                {
                    return BadRequest(new { Message = "Пользователь не найден." });
                }

                // Генерация новых токенов
                var newAccessToken = _tokenService.GenerateAccessToken(user);
                var newRefreshToken = _tokenService.GenerateRefreshToken();

                // Обновление refresh token в БД
                storedToken.RefreshToken = newRefreshToken;
                storedToken.RefreshTokenDatetime = DateTime.UtcNow.AddDays(7);
                _context.Tokens.Update(storedToken);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    access_token = newAccessToken,
                    refresh_token = newRefreshToken
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при обновлении токена");
                return StatusCode(500, new { Message = "Ошибка при обновлении токена." });
            }
        }

        //[Authorize]
        //[HttpGet("me")]
        //public async Task<IActionResult> GetCurrentUser()
        //{
        //    try
        //    {
        //        var userId = GetCurrentUserId();
        //        if (!userId.HasValue)
        //        {
        //            return Unauthorized(new { Message = "Пользователь не авторизован." });
        //        }

        //        var user = await _context.Users
        //            .Include(u => u.AccessLevel)
        //            .FirstOrDefaultAsync(u => u.Id == userId.Value);

        //        if (user == null)
        //        {
        //            return NotFound(new { Message = "Пользователь не найден." });
        //        }

        //        return Ok(new
        //        {
        //            user.Id,
        //            user.Username,
        //            user.Email,
        //            user.PhotoUrl,
        //            Role = AuthOptions.GetRoleName(user.AccessLevelId),
        //            RoleId = user.AccessLevelId,
        //            CanCreate = AuthOptions.CanCreateQuestionnaires(user.AccessLevelId),
        //            IsAdmin = AuthOptions.IsAdmin(user.AccessLevelId)
        //        });
        //    }
        //    catch (Exception ex)
        //    {
        //        _logger.LogError(ex, "Ошибка при получении данных пользователя");
        //        return StatusCode(500, new { Message = "Ошибка при получении данных пользователя." });
        //    }
        //}

        private int? GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(AuthOptions.UserIdClaimType)?.Value;
            if (int.TryParse(userIdClaim, out int userId))
            {
                return userId;
            }
            return null;
        }


        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteUser(int id)
        {
            var user = await _context.Users
                .Include(u => u.Tokens) // Токен
                .Include(u => u.Questionnaires) // Анкеты
                .Include(u => u.Answers) // Ответы      
                .FirstOrDefaultAsync(u => u.Id == id);

            if (user == null)
                return NotFound(new { message = "Пользователь не найден." });

            // Запрет на удаление самого себя
            var userIdClaim = User.FindFirst(AuthOptions.UserIdClaimType)?.Value;
            if (userIdClaim != null && int.Parse(userIdClaim) == id)
                return BadRequest(new { message = "Нельзя удалить свой собственный аккаунт." });

            try
            {
                // Удаление токена
                if (user.Tokens.Any())
                    _context.Tokens.RemoveRange(user.Tokens);

                // Удаление анкеты
                if (user.Questionnaires.Any())
                {
                    var questionnaireIds = user.Questionnaires.Select(q => q.Id).ToList();

                    // Удаление вопросов анкеты
                    var questions = await _context.Questions
                        .Where(q => questionnaireIds.Contains(q.QuestionnaireId))
                        .ToListAsync();
                    if (questions.Any())
                    {
                        _context.Questions.RemoveRange(questions);
                    }

                    // Удаление ответов анкеты
                    var answers = await _context.Answers
                        .Where(a => questions.Select(q => q.Id).Contains(a.QuestionId))
                        .ToListAsync();
                    if (answers.Any())
                    {
                        _context.Answers.RemoveRange(answers);
                    }

                    _context.Questionnaires.RemoveRange(user.Questionnaires);
                }

                // Удаление ответов самого пользователя
                if (user.Answers.Any())
                {
                    _context.Answers.RemoveRange(user.Answers);
                }

                // Удаление пользователя
                _context.Users.Remove(user);
                await _context.SaveChangesAsync();

                return Ok(new { message = "Пользователь и все связанные данные успешно удалены.", userId = id });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Ошибка при удалении пользователя.", error = ex.Message });
            }
        }
    }

    public class RefreshTokenRequest
    {
        public string AccessToken { get; set; } = null!;
        public string RefreshToken { get; set; } = null!;
    }
}