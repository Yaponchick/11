﻿namespace questionnaire.questionnaire.DTOs
{
    public class QuestionOrderDTO
    {
        public Guid QuestionId { get; set; }
        public int Order {  get; set; }
    }
}
