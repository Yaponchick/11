﻿using questionnaire.questionnaire.Authentication;

namespace questionnaire.questionnaire.DTOs
{
    public class RegisterRequest
    {
        public string Username { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string Password { get; set; } = null!;
        public int AccessLevelId { get; set; } = AuthOptions.RespondentRoleId;
    }
}
