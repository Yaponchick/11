﻿namespace questionnaire.questionnaire.DTOs
{
    public class UpdateQuestionTypeRequest
    {
        public int NewQuestionType { get; set; }
    }
}
