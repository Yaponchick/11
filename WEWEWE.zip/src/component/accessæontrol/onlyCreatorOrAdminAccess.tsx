import React from 'react';
import { Navigate } from 'react-router-dom';
import { getRoleFromToken } from '../../api/apiClient';

export const OnlyCreatorOrAdmin: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const role = getRoleFromToken();
    if (role !== 'Admin' && role !== 'Creator') 
        return <Navigate to="/accessDenied" replace />;
    return <>{children}</>;
};
