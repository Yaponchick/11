﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using questionnaire.questionnaire.Authentication;
using System;
using System.Text;
using Web.Models;
using Web.Services;

var builder = WebApplication.CreateBuilder(args);

// ===== ДОБАВЛЕНИЕ СЕРВИСОВ =====

// 1. Контроллеры
builder.Services.AddControllers();

// 2. Логирование (по желанию)
builder.Logging.ClearProviders();
builder.Logging.AddConsole();

// 3. Swagger с JWT
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "Введите токен в формате: Bearer {token}",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer"
    });

    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});
//builder.Services.AddAuthorization(options =>
//{
//    options.AddPolicy("AdminOnly", policy => policy.RequireRole("Admin"));
//    options.AddPolicy("CreatorOnly", policy => policy.RequireRole("Creator"));
//    options.AddPolicy("RespondentOnly", policy => policy.RequireRole("Respondent"));

//    options.AddPolicy("CreatorOrAdmin", policy =>
//        policy.RequireRole("Admin", "Creator"));

//    options.AddPolicy("RespondentOrHigher", policy =>
//        policy.RequireRole("Admin", "Creator", "Respondent"));
//});
// 4. Аутентификация JWT
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = AuthOptions.ISSUER,
            ValidAudience = AuthOptions.AUDIENCE,
            IssuerSigningKey = AuthOptions.GetSymmetricSecurityKey(),
        };
    });

// 5. Авторизация
builder.Services.AddAuthorization();

// 6. Подключение к БД
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
if (string.IsNullOrEmpty(connectionString))
{
    throw new InvalidOperationException("Строка подключения 'DefaultConnection' не найдена.");
}

builder.Services.AddDbContext<QuestionnaireContext>(options =>
    options.UseSqlServer(connectionString));

// 7. Сервис для токенов
builder.Services.AddScoped<TokenService>(provider =>
{
    var context = provider.GetRequiredService<QuestionnaireContext>();
    return new TokenService(
        context: context,
        jwtKey: AuthOptions.KEY,
        issuer: AuthOptions.ISSUER,
        audience: AuthOptions.AUDIENCE,
        lifetimeMinutes: AuthOptions.LIFETIME
    );
});

// 8. CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.WithOrigins("http://localhost:3000")
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials()
              .WithHeaders("X-Session-Id");
    });
});
builder.Services.AddTransient<IEmailService, EmailService>();
// ===== ПОСТРОЕНИЕ ПРИЛОЖЕНИЯ =====
var app = builder.Build();

app.UseCors("AllowAll");
app.UseStaticFiles();

// ===== НАСТРОЙКА PIPELINE (порядок важен!) =====

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// 1. CORS — ДО аутентификации
app.UseCors("AllowFrontend");

// 2. HTTPS
app.UseHttpsRedirection();

// 3. Аутентификация и авторизация
app.UseAuthentication(); // ← JWT
app.UseAuthorization();

// 4. Обработчик ошибок
app.UseExceptionHandler(errorApp =>
{
    errorApp.Run(async context =>
    {
        var logger = context.RequestServices.GetRequiredService<ILogger<Program>>();
        logger.LogError("Ошибка сервера: {StatusCode}", context.Response.StatusCode);
    });
});

// 5. Маршрутизация
app.MapControllers();

// ===== ЗАПУСК =====
app.Run();