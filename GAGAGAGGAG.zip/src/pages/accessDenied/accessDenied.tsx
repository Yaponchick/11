import './accessDeniedStyle.css'

function accessDenied() {
    return (
        <div className="Access-container">
            <div className="survey-pageAccess">
                <div className="text-Access">Отказано!</div>
                <div className="text-bottom">Недостаточный уровень прав</div>

            </div>
        </div>
    )
}

export default accessDenied;