import { Auth, Main, Pas, SurveyPage, Navbar, Account, Answers, Thanks, RepeatedResponse, Eror404, Eror500, AnalysisPage, AdminPanel, AccessDenied } from '../pages';
// import {Respas} from '../pages/ResPas';
import { BrowserRouter as Router, Routes, Route, useLocation, useNavigate } from 'react-router-dom';

import { OnlyAdmin } from '../component/accessСontrol/onlyAdminAccess';
import { OnlyCreatorOrAdmin } from '../component/accessСontrol/onlyCreatorOrAdminAccess';
import { OnlyRespondent } from '../component/accessСontrol/onlyRespondentAccess';
import { useAppDispatch } from '../store/strore';
import { useEffect } from 'react';
import { checkToken } from '../store/auth/actions';
import { OnlyAuth, OnlyUnAuth } from '../component';
import { AuthProvider } from '../api/AuthContext';
import { getRoleFromToken } from '../api/apiClient';

export const App = () => {
	const location = useLocation();
	const state = location.state as { backgroundLocation?: Location };
	const dispatch = useAppDispatch();

	const navigate = useNavigate();
	const role = getRoleFromToken();

	useEffect(() => {
		dispatch(checkToken());
	}, []);

	return (
		// <Router> <Navbar/> location={state?.backgroundLocation || location}
		<>
			<AuthProvider>
				<Navbar />
				<Routes>
					<Route path='/' element={<OnlyAuth component={<Main />} />} />
					<Route path='/auth' element={<Auth />} />
					<Route path='/resPassword' element={<Pas />} />
					<Route path='/SurveyPage' element={<SurveyPage />} />
					<Route path='/Account' element={<Account />} />
					<Route path="/Answers/:id" element={<Answers />} />
					<Route path="/Thanks" element={<Thanks />} />
					<Route path="/RepeatedResponse" element={<RepeatedResponse />} />
					<Route path="/Eror500" element={<Eror500 />} />
					<Route path="/AnalysisPage/:id" element={<AnalysisPage />} />
					<Route path='/edit-survey/:surveyId' element={<SurveyPage />} />

					<Route path="/AdminPanel"

						element={
							<OnlyAdmin>
								<AdminPanel />
							</OnlyAdmin>
						} />

					<Route path='AccessDenied' element={<AccessDenied />} />
					<Route path="*" element={<Eror404 />} />


				</Routes>
			</AuthProvider>
		</>

	);
};



// import { Auth, Main, Pas, SurveyPage, Navbar, Account, Answers, Thanks, RepeatedResponse, Eror404, Eror500, AnalysisPage } from '../pages';
// import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';

// import { useAppDispatch } from '../store/strore';
// import { useEffect } from 'react';
// import { checkToken } from '../store/auth/actions';
// import { OnlyAuth, OnlyUnAuth } from '../component';
// import { AuthProvider } from '../api/AuthContext';

// export const App = () => {
// 	const location = useLocation();
// 	const state = location.state as { backgroundLocation?: Location };
// 	const dispatch = useAppDispatch();

// 	useEffect(() => {
// 		dispatch(checkToken());
// 	}, []);

// 	return (
// 		// <Router> <Navbar/> location={state?.backgroundLocation || location}
// 		<>
// 			<AuthProvider>
// 				<Navbar />
// 				<Routes>
// 					<Route path='/' element={<OnlyAuth component={<Main />} />} />
// 					<Route path='/auth' element={<Auth />} />
// 					<Route path='/resPassword' element={<Pas />} />
// 					<Route path="/SurveyPage" element={<OnlyAuth component={<SurveyPage />} />} />
// 					<Route path="/Account" element={<OnlyAuth component={<Account />} />} />
// 					<Route path="/Answers/:id" element={<OnlyAuth component={<Answers />} />} />
// 					<Route path="/Thanks" element={<OnlyAuth component={<Thanks />} />} />
// 					<Route path="/RepeatedResponse" element={<OnlyAuth component={<RepeatedResponse />} />} />
// 					<Route path="/AnalysisPage/:id" element={<OnlyAuth component={<AnalysisPage />} />} />
// 					<Route path="/edit-survey/:surveyId" element={<OnlyAuth component={<SurveyPage />} />} />
// 					<Route path="/Eror500" element={<Eror500 />} />
// 					<Route path="*" element={<Eror404 />} />


// 				</Routes>
// 			</AuthProvider>
// 		</>

// 	);
// };
